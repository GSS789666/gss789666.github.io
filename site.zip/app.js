const input=document.getElementById('paper-search');
const filter=document.getElementById('paper-filter');
function filterPapers(){let shown=0;for(const li of document.querySelectorAll('.publication-list li')){const match=li.textContent.toLocaleLowerCase().includes(input.value.trim().toLocaleLowerCase())&&(filter.value==='all'||filter.value===li.dataset.status);li.hidden=!match;if(match)shown++;}document.getElementById('no-results').hidden=shown>0;}
input?.addEventListener('input',filterPapers);filter?.addEventListener('change',filterPapers);
document.querySelector('[data-print]')?.addEventListener('click',()=>window.print());
